function [sys,x0,str,ts,simStateCompliance] = sfuntmpl(t,x,u,flag)
switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 12;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 4;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   
sys = simsizes(sizes);
x0  = [0 0 0 -.5 0 0 0 0 0 0 0 0];
str = [];
ts  = [0 0];
simStateCompliance = 'UnknownSimState';
function sys=mdlDerivatives(t,x,u)
x1=x(1);x2=x(2);x3=x(3);theta=x(4);d=u;
q1=exp(-(x1-1)^2/4);q2=exp(-(x1-.5)^2/4);q3=exp(-(x1-0)^2/4);q4=exp(-(x1+.5)^2/4);q5=exp(-(x1+1)^2/4);
p1=exp(-(x2-1)^2/16);p2=exp(-(x2-.5)^2/16);p3=exp(-(x2-0)^2/16);p4=exp(-(x2+.5)^2/16);p5=exp(-(x2+1)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi2=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

q1=exp(-(x2-1)^2/4);q2=exp(-(x2-.5)^2/4);q3=exp(-(x2-0)^2/4);q4=exp(-(x2+.5)^2/4);q5=exp(-(x2+1)^2/4);
p1=exp(-(x3-10)^2/16);p2=exp(-(x3-5)^2/16);p3=exp(-(x3-0)^2/16);p4=exp(-(x3+5)^2/16);p5=exp(-(x3+10)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi3=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

y=x1;xd=x(5);
x2c=x(6);x2cd=x(7);x3c=x(8);x3cd=x(9);
s1=x(10);s2=x(11);s3=x(12);
z1=x1-xd;
z2=x2-x2c;
z3=x3-x3c;
nu1=z1-s1;
nu2=z2-s2;
nu3=z3-s3;

rg=pi/4;
xdd=-2*xd+2*rg;
c1=40;c2=40;c3=40;
l2=1;l3=2;
alpha1=-c1*z1+xdd;
alpha2=-c2*z2-.5*nu2-z1+x2cd-nu2*theta*phi2'*phi2/(2*l2^2);
v3=-c3*z3-.5*nu3+z2+x3cd-1/(2*l3^2)*nu3*theta*phi3'*phi3;
wn=2000;zeta=.4;

sys=[x2;-10*sin(x1)-x2+x3+d;-200*x2-10*x3+20*v3;
     .01*nu2^2*phi2'*phi2/(2*l2^2)+.1*nu3^2*phi3'*phi3/(2*l3^2)-.1*theta;
     xdd;
     wn*x2cd;-2*zeta*wn*x2cd-wn*(x2c-alpha1);
     wn*x3cd;-2*zeta*wn*x3cd-wn*(x3c-alpha2);
     -c1*s1+s2+(x2c-alpha1);
     -c2*s2-s1+s2+x3c-alpha2;
     -c3*s3-s2];
function sys=mdlUpdate(t,x,u)
sys = [];
function sys=mdlOutputs(t,x,u)
x1=x(1);x2=x(2);x3=x(3);theta=x(4);d=u;

q1=exp(-(x1-1)^2/4);q2=exp(-(x1-.5)^2/4);q3=exp(-(x1-0)^2/4);q4=exp(-(x1+.5)^2/4);q5=exp(-(x1+1)^2/4);
p1=exp(-(x2-1)^2/16);p2=exp(-(x2-.5)^2/16);p3=exp(-(x2-0)^2/16);p4=exp(-(x2+.5)^2/16);p5=exp(-(x2+1)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi2=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

q1=exp(-(x2-1)^2/4);q2=exp(-(x2-.5)^2/4);q3=exp(-(x2-0)^2/4);q4=exp(-(x2+.5)^2/4);q5=exp(-(x2+1)^2/4);
p1=exp(-(x3-10)^2/16);p2=exp(-(x3-5)^2/16);p3=exp(-(x3-0)^2/16);p4=exp(-(x3+5)^2/16);p5=exp(-(x3+10)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi3=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

y=x1;xd=x(5);
x2c=x(6);x2cd=x(7);x3c=x(8);x3cd=x(9);
s1=x(10);s2=x(11);s3=x(12);

z1=x1-xd;
z2=x2-x2c;
z3=x3-x3c;
nu1=z1-s1;
nu2=z2-s2;
nu3=z3-s3;

rg=pi/4;
xdd=-2*xd+2*rg;
c1=40;c2=40;c3=40;
l2=1;l3=2;
alpha1=-c1*z1+xdd;
alpha2=-c2*z2-.5*nu2-z1+x2cd-nu2*theta*phi2'*phi2/(2*l2^2);
v3=-c3*z3-.5*nu3+z2+x3cd-1/(2*l3^2)*nu3*theta*phi3'*phi3;
wn=2000;zeta=.4;
k1=(.5-.01)*exp(-t)+.01;
sys =[x1-xd;k1;-k1;v3];
function sys=mdlGetTimeOfNextVarHit(t,x,u)
sampleTime = 1;   
sys = t + sampleTime;
function sys=mdlTerminate(t,x,u)
sys = [];