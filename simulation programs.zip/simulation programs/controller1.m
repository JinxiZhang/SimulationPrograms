function [sys,x0,str,ts,simStateCompliance] = sfuntmpl(t,x,u,flag)
switch flag,
  case 0,
    [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes;
  case 1,
    sys=mdlDerivatives(t,x,u);
  case 2,
    sys=mdlUpdate(t,x,u);
  case 3,
    sys=mdlOutputs(t,x,u);
  case 4,
    sys=mdlGetTimeOfNextVarHit(t,x,u);
  case 9,
    sys=mdlTerminate(t,x,u);
  otherwise
    DAStudio.error('Simulink:blocks:unhandledFlag', num2str(flag));
end
function [sys,x0,str,ts,simStateCompliance]=mdlInitializeSizes
sizes = simsizes;
sizes.NumContStates  = 14;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 18;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;   
sys = simsizes(sizes);
x0  = [0 0 0 -.5 -.5 -.5 -.5 -.5 -1 -1 -1 -1 -1 0];
str = [];
ts  = [0 0];
simStateCompliance = 'UnknownSimState';
function sys=mdlDerivatives(t,x,u)
x1=x(1);x2=x(2);x3=x(3);
theta1=[x(4);x(5);x(6);x(7);x(8)];
theta2=[x(9);x(10);x(11);x(12);x(13)];

q1=exp(-(x1-1)^2/4);q2=exp(-(x1-.5)^2/4);q3=exp(-(x1-0)^2/4);q4=exp(-(x1+.5)^2/4);q5=exp(-(x1+1)^2/4);
p1=exp(-(x2-1)^2/16);p2=exp(-(x2-.5)^2/16);p3=exp(-(x2-0)^2/16);p4=exp(-(x2+.5)^2/16);p5=exp(-(x2+1)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi1=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

q1=exp(-(x2-1)^2/4);q2=exp(-(x2-.5)^2/4);q3=exp(-(x2-0)^2/4);q4=exp(-(x2+.5)^2/4);q5=exp(-(x2+1)^2/4);
p1=exp(-(x3-10)^2/16);p2=exp(-(x3-5)^2/16);p3=exp(-(x3-0)^2/16);p4=exp(-(x3+5)^2/16);p5=exp(-(x3+10)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi2=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

y=x1;r=x(14);
c1=1;c2=10;c3=20;
e1=y-r;
k1=(.5-.01)*exp(-t)+.01;
v1=-c1*tan(pi/2*e1/k1);
e2=x2-v1;
k2=(1-.5)*exp(-.5*t)+.5;
v2=-c2*tan(pi/2*e2/k2)-theta1'*phi1;
e3=x3-v2;
k3=(2-1)*exp(-.5*t)+1;
v3=-c3*tan(pi/2*e3/k3)-theta2'*phi2;

d=u;l1=5;l2=50;

xi1=1/cos(pi/2*e2/k2)^2;
xi2=1/cos(pi/2*e3/k3)^2;
rg=pi/4;

sys=[x2;
    -10*sin(x1)-x2+x3+d;
    -200*x2-10*x3+20*v3;
    -theta1+l1*tan(pi/2*e2/k2)/k2/xi1*phi1;
    -theta2+l2*tan(pi/2*e3/k3)/k3/xi2*phi2;
    -2*x(14)+2*rg];
function sys=mdlUpdate(t,x,u)
sys = [];
function sys=mdlOutputs(t,x,u)
x1=x(1);x2=x(2);x3=x(3);
theta1=[x(4);x(5);x(6);x(7);x(8)];
theta2=[x(9);x(10);x(11);x(12);x(13)];

q1=exp(-(x1-1)^2/4);q2=exp(-(x1-.5)^2/4);q3=exp(-(x1-0)^2/4);q4=exp(-(x1+.5)^2/4);q5=exp(-(x1+1)^2/4);
p1=exp(-(x2-1)^2/16);p2=exp(-(x2-.5)^2/16);p3=exp(-(x2-0)^2/16);p4=exp(-(x2+.5)^2/16);p5=exp(-(x2+1)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi1=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

q1=exp(-(x2-1)^2/4);q2=exp(-(x2-.5)^2/4);q3=exp(-(x2-0)^2/4);q4=exp(-(x2+.5)^2/4);q5=exp(-(x2+1)^2/4);
p1=exp(-(x3-10)^2/16);p2=exp(-(x3-5)^2/16);p3=exp(-(x3-0)^2/16);p4=exp(-(x3+5)^2/16);p5=exp(-(x3+10)^2/16);
w1=p1*q1;w2=p2*q2;w3=p3*q3;w4=p4*q4;w5=p5*q5; 
phi2=1/(w1+w2+w3+w4+w5)*[w1;w2;w3;w4;w5];

y=x1;r=x(14);
c1=1;c2=10;c3=20;
e1=y-r;
k1=(.5-.01)*exp(-t)+.01;
v1=-c1*tan(pi/2*e1/k1);
e2=x2-v1;
k2=(1-.5)*exp(-.5*t)+.5;
v2=-c2*tan(pi/2*e2/k2)-theta1'*phi1;
e3=x3-v2;
k3=(2-1)*exp(-.5*t)+1;
v3=-c3*tan(pi/2*e3/k3)-theta2'*phi2;

sys =[y;r;e1;k1;-k1;x2;x3;v3;theta1;theta2];
function sys=mdlGetTimeOfNextVarHit(t,x,u)
sampleTime = 1;   
sys = t + sampleTime;
function sys=mdlTerminate(t,x,u)
sys = [];